package main

import (
	"context"
	"crypto/tls"
	"fmt"
	"log"
	"net"
	"os"

	"github.com/quic-go/quic-go"
	"jarkom.cs.ui.ac.id/h01/project/utils"
)

const (
	serverIP          = "10.142.0.2"
	serverPort        = "8932"
	serverType        = "udp4"
	bufferSize        = 2048
	appLayerProto     = "lrt-jabodebek-2206028932"
	sslKeyLogFileName = "ssl-key.log"
)

func main() {
	arrival := utils.LRTPIDSPacket{
		LRTPIDSPacketFixed: utils.LRTPIDSPacketFixed{
			TransactionId:     0x55,
			IsAck:             false,
			IsNewTrain:        false,
			IsUpdateTrain:     false,
			IsDeleteTrain:     false,
			IsTrainArriving:   true,
			IsTrainDeparting:  false,
			TrainNumber:       42,
			DestinationLength: uint8(len("Harjamukti")),
		},
		Destination: "Harjamukti",
	}
	resultArrival := utils.Encoder(arrival)

	departure := utils.LRTPIDSPacket{
		LRTPIDSPacketFixed: utils.LRTPIDSPacketFixed{
			TransactionId:     0x56,
			IsAck:             false,
			IsNewTrain:        false,
			IsUpdateTrain:     false,
			IsDeleteTrain:     false,
			IsTrainArriving:   false,
			IsTrainDeparting:  true,
			TrainNumber:       42,
			DestinationLength: uint8(len("Harjamukti")),
		},
		Destination: "Harjamukti",
	}
	resultDeparture := utils.Encoder(departure)

	sslKeyLogFile, err := os.Create(sslKeyLogFileName)
	if err != nil {
		log.Fatalln(err)
	}
	defer sslKeyLogFile.Close()

	fmt.Printf("NODE KENDALI STASIUN\n")

	tlsConfig := &tls.Config{
		InsecureSkipVerify: true,
		NextProtos:         []string{appLayerProto},
		KeyLogWriter:       sslKeyLogFile,
	}
	connection, err := quic.DialAddr(context.Background(), net.JoinHostPort(serverIP, serverPort), tlsConfig, &quic.Config{})
	if err != nil {
		log.Fatalln(err)
	}

	fmt.Printf("[quic] Dialling from %s to %s\n", connection.LocalAddr(), connection.RemoteAddr())

	fmt.Printf("[quic] Creating receive buffer of size %d\n\n", bufferSize)
	receiveBuffer := make([]byte, bufferSize)

	packets := [2]utils.LRTPIDSPacket{arrival, departure}
	results := [2][]byte{resultArrival, resultDeparture}

	for i := 0; i < 2; i++ {
		stream, err := connection.OpenStreamSync(context.Background())
		if err != nil {
			log.Fatalln(err)
		}
		fmt.Printf("[quic] Opened bidirectional stream %d to %s\n", stream.StreamID(), connection.RemoteAddr())

		fmt.Printf("[quic] [Stream ID: %d] Sending message '%v'\n", stream.StreamID(), packets[i])
		_, err = stream.Write([]byte(results[i]))
		if err != nil {
			log.Fatalln(err)
		}
		fmt.Printf("[quic] [Stream ID: %d] Message sent\n", stream.StreamID())

		receiveLength, err := stream.Read(receiveBuffer)
		if err != nil {
			log.Fatalln(err)
		}
		fmt.Printf("[quic] [Stream ID: %d] Received %d bytes of message from server\n", stream.StreamID(), receiveLength)

		response := receiveBuffer[:receiveLength]
		fmt.Printf("[quic] [Stream ID: %d] Received message: %v\n\n", stream.StreamID(), utils.Decoder(response))
	}
}
